package com.example.thirst;

import com.example.thirst.command.ThirstCommand;
import com.example.thirst.listener.PlayerDrinkListener;
import com.example.thirst.listener.ThirstEffectListener;
import com.example.thirst.manager.SpringManager;
import com.example.thirst.manager.ThirstManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class ThirstPlugin extends JavaPlugin {

    private static ThirstPlugin instance;

    private ThirstManager thirstManager;
    private SpringManager springManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        springManager = new SpringManager(this);
        thirstManager = new ThirstManager(this);

        getServer().getPluginManager().registerEvents(new PlayerDrinkListener(this), this);
        getServer().getPluginManager().registerEvents(new ThirstEffectListener(this), this);

        getCommand("thirst").setExecutor(new ThirstCommand(this));

        long depletionInterval = getConfig().getLong("depletion-interval-ticks", 600L);
        getServer().getScheduler().runTaskTimer(this,
                () -> thirstManager.depleteAll(), 200L, depletionInterval);

        long actionbarInterval = getConfig().getLong("actionbar-update-ticks", 20L);
        getServer().getScheduler().runTaskTimer(this,
                () -> thirstManager.updateActionbars(), 20L, actionbarInterval);

        long rainInterval = getConfig().getLong("rain-check-interval-ticks", 100L);
        getServer().getScheduler().runTaskTimer(this,
                () -> thirstManager.checkRain(), 100L, rainInterval);

        long damageInterval = getConfig().getLong("dehydration-damage-interval-ticks", 100L);
        getServer().getScheduler().runTaskTimer(this,
                () -> thirstManager.applyDehydrationDamage(), 100L, damageInterval);

        getLogger().info("Thirst plugin enabled!");
    }

    @Override
    public void onDisable() {
        thirstManager.saveData();
        springManager.saveData();
        getLogger().info("Thirst plugin disabled.");
    }

    public static ThirstPlugin getInstance() { return instance; }
    public ThirstManager getThirstManager() { return thirstManager; }
    public SpringManager getSpringManager() { return springManager; }

    public void reload() {
        reloadConfig();
        thirstManager.reload();
    }
}
