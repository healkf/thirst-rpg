package com.example.thirst.command;

import com.example.thirst.ThirstPlugin;
import com.example.thirst.manager.SpringManager;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;

public class ThirstCommand implements CommandExecutor, TabCompleter {

    private final ThirstPlugin plugin;

    public ThirstCommand(ThirstPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("thirst.admin")) {
            sender.sendMessage(ChatColor.RED + "Нет доступа.");
            return true;
        }

        if (args.length == 0) { sendHelp(sender); return true; }

        switch (args[0].toLowerCase()) {

            case "addspring" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Только игрок может использовать эту команду.");
                    return true;
                }
                Location loc = player.getLocation();
                plugin.getSpringManager().addSpring(loc);
                sender.sendMessage(ChatColor.GREEN + "[Thirst] Родник добавлен на "
                        + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ()
                        + " (радиус " + plugin.getConfig().getDouble("spring-radius", 3.0) + " блоков).");
            }

            case "removespring" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Только игрок может использовать эту команду.");
                    return true;
                }
                boolean removed = plugin.getSpringManager().removeNearest(player.getLocation(), 10.0);
                if (removed) {
                    sender.sendMessage(ChatColor.GREEN + "[Thirst] Ближайший родник удалён.");
                } else {
                    sender.sendMessage(ChatColor.RED + "[Thirst] Нет родника в радиусе 10 блоков.");
                }
            }

            case "listsprings" -> {
                SpringManager sm = plugin.getSpringManager();
                if (sm.getSprings().isEmpty()) {
                    sender.sendMessage(ChatColor.YELLOW + "[Thirst] Родников нет.");
                    return true;
                }
                sender.sendMessage(ChatColor.GOLD + "=== Родники (" + sm.getSprings().size() + ") ===");
                int i = 1;
                for (Location loc : sm.getSprings()) {
                    sender.sendMessage(ChatColor.YELLOW + "" + i++ + ". "
                            + ChatColor.WHITE + loc.getWorld().getName()
                            + " " + loc.getBlockX()
                            + ", " + loc.getBlockY()
                            + ", " + loc.getBlockZ());
                }
            }

            case "set" -> {
                if (args.length < 3) { sendHelp(sender); return true; }
                Player target = plugin.getServer().getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(ChatColor.RED + "Игрок не найден.");
                    return true;
                }
                try {
                    int val = Integer.parseInt(args[2]);
                    plugin.getThirstManager().setThirst(target, val);
                    sender.sendMessage(ChatColor.GREEN + "Жажда " + target.getName() + " установлена на " + val + ".");
                } catch (NumberFormatException e) {
                    sender.sendMessage(ChatColor.RED + "Введите число.");
                }
            }

            case "reload" -> {
                plugin.reload();
                sender.sendMessage(ChatColor.GREEN + "[Thirst] Конфиг перезагружен.");
            }

            default -> sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "=== Thirst ===");
        sender.sendMessage(ChatColor.YELLOW + "/thirst addspring        " + ChatColor.GRAY + "- добавить родник на вашей позиции");
        sender.sendMessage(ChatColor.YELLOW + "/thirst removespring     " + ChatColor.GRAY + "- удалить ближайший родник (10 блоков)");
        sender.sendMessage(ChatColor.YELLOW + "/thirst listsprings      " + ChatColor.GRAY + "- список всех родников");
        sender.sendMessage(ChatColor.YELLOW + "/thirst set <игрок> <N>  " + ChatColor.GRAY + "- установить жажду игрока");
        sender.sendMessage(ChatColor.YELLOW + "/thirst reload           " + ChatColor.GRAY + "- перезагрузить конфиг");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("addspring", "removespring", "listsprings", "set", "reload");
        return List.of();
    }
}
