package com.example.thirst.manager;

import com.example.thirst.ThirstPlugin;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

public class ThirstManager {

    private final ThirstPlugin plugin;

    // Player UUID → current thirst level
    private final Map<UUID, Integer> thirstMap = new HashMap<>();

    private int maxThirst;
    private int slownessThreshold;
    private int fatigueThreshold;
    private int weaknessThreshold;
    private int rainRestoreAmount;
    private String symbolFull;
    private String symbolEmpty;

    private File dataFile;

    public ThirstManager(ThirstPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "thirst_data.yml");
        load();
        loadData();
    }

    private void load() {
        maxThirst          = plugin.getConfig().getInt("max-thirst", 20);
        slownessThreshold  = plugin.getConfig().getInt("slowness-threshold", 10);
        fatigueThreshold   = plugin.getConfig().getInt("fatigue-threshold", 6);
        weaknessThreshold  = plugin.getConfig().getInt("weakness-threshold", 3);
        rainRestoreAmount  = plugin.getConfig().getInt("rain-restore-amount", 1);
        symbolFull         = plugin.getConfig().getString("symbol-full", "💧");
        symbolEmpty        = plugin.getConfig().getString("symbol-empty", "○");
    }

    public void reload() { load(); }

    // ── Public API ────────────────────────────────────────────────────────────

    public int getThirst(Player player) {
        return thirstMap.getOrDefault(player.getUniqueId(), maxThirst);
    }

    public void setThirst(Player player, int value) {
        thirstMap.put(player.getUniqueId(), Math.max(0, Math.min(maxThirst, value)));
    }

    public void addThirst(Player player, int amount) {
        setThirst(player, getThirst(player) + amount);
    }

    public void removeThirst(Player player, int amount) {
        setThirst(player, getThirst(player) - amount);
    }

    // ── Scheduled tasks ───────────────────────────────────────────────────────

    /** Called by depletion task — reduce thirst by 1 for all online players. */
    public void depleteAll() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            if (player.hasPermission("thirst.bypass")) continue;
            removeThirst(player, 1);
            applyThirstEffects(player);
        }
    }

    /** Update actionbar for all online players. */
    public void updateActionbars() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            sendActionbar(player);
        }
    }

    /** Restore thirst for players standing in rain with sky access. */
    public void checkRain() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            if (!player.getWorld().hasStorm()) continue;
            if (!hasSkyAccess(player)) continue;
            addThirst(player, rainRestoreAmount);
        }
    }

    /** Deal 1 damage to completely dehydrated players. */
    public void applyDehydrationDamage() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            if (getThirst(player) <= 0) {
                player.damage(1.0);
            }
        }
    }

    // ── Actionbar ─────────────────────────────────────────────────────────────

    private void sendActionbar(Player player) {
        int thirst     = getThirst(player);
        int drops      = maxThirst / 2;           // number of droplet icons
        int filledFull = thirst / 2;              // fully filled drops
        boolean half   = (thirst % 2) == 1;      // one half-filled drop

        StringBuilder bar = new StringBuilder();

        // Color based on thirst level
        ChatColor color;
        if (thirst > slownessThreshold)  color = ChatColor.AQUA;
        else if (thirst > fatigueThreshold) color = ChatColor.YELLOW;
        else if (thirst > weaknessThreshold) color = ChatColor.GOLD;
        else                              color = ChatColor.RED;

        bar.append(color);

        for (int i = 0; i < drops; i++) {
            if (i < filledFull) {
                bar.append(symbolFull);
            } else if (i == filledFull && half) {
                bar.append(ChatColor.GRAY).append(symbolFull).append(color);
            } else {
                bar.append(ChatColor.DARK_GRAY).append(symbolEmpty).append(color);
            }
        }

        player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                new TextComponent(bar.toString()));
    }

    // ── Effects based on thirst ───────────────────────────────────────────────

    private void applyThirstEffects(Player player) {
        int thirst = getThirst(player);

        // Remove previous thirst effects so they don't stack
        player.removePotionEffect(PotionEffectType.SLOWNESS);
        player.removePotionEffect(PotionEffectType.MINING_FATIGUE);
        player.removePotionEffect(PotionEffectType.WEAKNESS);

        int duration = 700; // slightly longer than depletion interval so effect persists

        if (thirst <= 0) {
            // All effects at max severity
            applyEffect(player, PotionEffectType.SLOWNESS,      duration, 1);
            applyEffect(player, PotionEffectType.MINING_FATIGUE, duration, 1);
            applyEffect(player, PotionEffectType.WEAKNESS,      duration, 1);
        } else if (thirst <= weaknessThreshold) {
            applyEffect(player, PotionEffectType.SLOWNESS,      duration, 0);
            applyEffect(player, PotionEffectType.MINING_FATIGUE, duration, 0);
            applyEffect(player, PotionEffectType.WEAKNESS,      duration, 0);
        } else if (thirst <= fatigueThreshold) {
            applyEffect(player, PotionEffectType.SLOWNESS,      duration, 0);
            applyEffect(player, PotionEffectType.MINING_FATIGUE, duration, 0);
        } else if (thirst <= slownessThreshold) {
            applyEffect(player, PotionEffectType.SLOWNESS,      duration, 0);
        }
    }

    private void applyEffect(Player player, PotionEffectType type, int duration, int amplifier) {
        player.addPotionEffect(new PotionEffect(type, duration, amplifier, false, false, true));
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * Checks whether the player has an unobstructed view of the sky
     * (for rain hydration).
     */
    private boolean hasSkyAccess(Player player) {
        Location loc = player.getLocation();
        int topY = player.getWorld().getHighestBlockYAt(loc);
        return loc.getBlockY() >= topY;
    }

    // ── Persistence ───────────────────────────────────────────────────────────

    public void saveData() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Map.Entry<UUID, Integer> e : thirstMap.entrySet()) {
            cfg.set("thirst." + e.getKey().toString(), e.getValue());
        }
        try {
            plugin.getDataFolder().mkdirs();
            cfg.save(dataFile);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Could not save thirst_data.yml", ex);
        }
    }

    private void loadData() {
        if (!dataFile.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(dataFile);
        if (!cfg.isConfigurationSection("thirst")) return;
        for (String key : cfg.getConfigurationSection("thirst").getKeys(false)) {
            try {
                thirstMap.put(UUID.fromString(key), cfg.getInt("thirst." + key));
            } catch (IllegalArgumentException ignored) {}
        }
    }
}
