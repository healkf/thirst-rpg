package com.example.thirst.listener;

import com.example.thirst.ThirstPlugin;
import com.example.thirst.manager.SpringManager;
import com.example.thirst.manager.ThirstManager;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

public class PlayerDrinkListener implements Listener {

    private final ThirstPlugin plugin;
    private final Random rng = new Random();

    private final Map<UUID, BukkitTask> diarrheaTasks = new HashMap<>();

    private static final Set<Material> WATER_BLOCKS = Set.of(
            Material.WATER, Material.KELP_PLANT, Material.KELP,
            Material.SEAGRASS, Material.TALL_SEAGRASS
    );

    public PlayerDrinkListener(ThirstPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        plugin.getThirstManager().getThirst(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        BukkitTask task = diarrheaTasks.remove(id);
        if (task != null) task.cancel();
    }

    @SuppressWarnings("deprecation")
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        Player player = event.getPlayer();
        Block target = null;

        // 1
        if (event.getClickedBlock() != null && WATER_BLOCKS.contains(event.getClickedBlock().getType())) {
            target = event.getClickedBlock();
        }
        // 2
        if (target == null) {
            try {
                Block ray = player.getTargetBlock(null, 5);
                if (ray != null && WATER_BLOCKS.contains(ray.getType())) target = ray;
            } catch (Exception ignored) {}
        }
        // 3
        if (target == null) {
            Block feet = player.getLocation().getBlock();
            Block body = player.getLocation().clone().add(0, 1, 0).getBlock();
            if (WATER_BLOCKS.contains(feet.getType())) target = feet;
            else if (WATER_BLOCKS.contains(body.getType())) target = body;
        }

        if (target == null) return;

        ThirstManager tm = plugin.getThirstManager();
        SpringManager sm = plugin.getSpringManager();

        int currentThirst = tm.getThirst(player);
        int maxThirst = plugin.getConfig().getInt("max-thirst", 20);

        if (currentThirst >= maxThirst) {
            player.sendMessage(ChatColor.AQUA + "Вы не хотите пить.");
            return;
        }

        boolean nearSpring = sm.isNearSpring(target.getLocation());

        if (nearSpring) {
            int restore = plugin.getConfig().getInt("spring-restore-amount", 20);
            tm.addThirst(player, restore);
            player.playSound(player.getLocation(), Sound.ENTITY_GENERIC_DRINK, 1f, 1f);
            player.sendMessage(ChatColor.AQUA + "Вы попили чистой воды из родника. Освежает!");
        } else {
            int restore = plugin.getConfig().getInt("dirty-water-restore-amount", 6);
            tm.addThirst(player, restore);
            player.playSound(player.getLocation(), Sound.ENTITY_GENERIC_DRINK, 1f, 0.8f);
            player.sendMessage(ChatColor.YELLOW + "Вы попили воды из водоёма. Не самая чистая вода...");

            double chance = plugin.getConfig().getDouble("diarrhea-chance", 0.75);
            if (rng.nextDouble() < chance) {
                triggerDiarrhea(player);
            }
        }
    }

    private void triggerDiarrhea(Player player) {
        UUID id = player.getUniqueId();

        BukkitTask existing = diarrheaTasks.remove(id);
        if (existing != null) existing.cancel();

        int duration     = plugin.getConfig().getInt("diarrhea-duration-ticks", 200);
        int woolInterval = plugin.getConfig().getInt("diarrhea-wool-interval-ticks", 15);

        player.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, duration, 0, false, true, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.POISON, duration / 2, 0, false, true, true));
        player.sendMessage(ChatColor.DARK_GREEN + "Вас скрутило от грязной воды...");

        plugin.getThirstManager().removeThirst(player, 4);

        int[] ticksElapsed = {0};

        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline()) {
                diarrheaTasks.remove(id);
                return;
            }

            dropBrownWool(player);
            ticksElapsed[0] += woolInterval;

            if (ticksElapsed[0] >= duration) {
                BukkitTask t = diarrheaTasks.remove(id);
                if (t != null) t.cancel();
            }
        }, woolInterval, woolInterval);

        diarrheaTasks.put(id, task);
    }

    private void dropBrownWool(Player player) {
        Location loc = player.getLocation().clone().subtract(0, 0.3, 0);

        loc.add(
                (rng.nextDouble() - 0.5) * 0.4,
                0,
                (rng.nextDouble() - 0.5) * 0.4
        );

        Item item = player.getWorld().dropItem(loc, new ItemStack(Material.BROWN_WOOL));

        item.setPickupDelay(Integer.MAX_VALUE);

        item.setVelocity(new Vector(
                (rng.nextDouble() - 0.5) * 0.1,
                0.05,
                (rng.nextDouble() - 0.5) * 0.1
        ));

        int despawnTicks = plugin.getConfig().getInt("diarrhea-wool-despawn-ticks", 60);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (item.isValid()) item.remove();
        }, despawnTicks);
    }
}
