package com.example.thirst.manager;

import com.example.thirst.ThirstPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

/**
 * Stores and persists spring locations registered by admins.
 * A "spring" is simply a saved Location. Players who right-click
 * water within {@code spring-radius} blocks of any spring get clean water.
 */
public class SpringManager {

    private final ThirstPlugin plugin;
    private final List<Location> springs = new ArrayList<>();
    private File dataFile;

    public SpringManager(ThirstPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "springs.yml");
        loadData();
    }

    // ── Public API ────────────────────────────────────────────────────────────

    public void addSpring(Location loc) {
        springs.add(loc.clone());
        saveData();
    }

    public boolean removeNearest(Location loc, double maxDistance) {
        Location nearest = null;
        double bestDist = Double.MAX_VALUE;
        for (Location s : springs) {
            if (!s.getWorld().equals(loc.getWorld())) continue;
            double d = s.distanceSquared(loc);
            if (d < bestDist) { bestDist = d; nearest = s; }
        }
        if (nearest != null && Math.sqrt(bestDist) <= maxDistance) {
            springs.remove(nearest);
            saveData();
            return true;
        }
        return false;
    }

    public List<Location> getSprings() {
        return List.copyOf(springs);
    }

    /**
     * Returns true if the given location is within the configured spring radius
     * of any registered spring.
     */
    public boolean isNearSpring(Location loc) {
        double radius = plugin.getConfig().getDouble("spring-radius", 3.0);
        for (Location s : springs) {
            if (!s.getWorld().equals(loc.getWorld())) continue;
            if (s.distance(loc) <= radius) return true;
        }
        return false;
    }

    // ── Persistence ───────────────────────────────────────────────────────────

    public void saveData() {
        YamlConfiguration cfg = new YamlConfiguration();
        List<String> list = new ArrayList<>();
        for (Location loc : springs) {
            list.add(loc.getWorld().getName() + ","
                    + loc.getBlockX() + ","
                    + loc.getBlockY() + ","
                    + loc.getBlockZ());
        }
        cfg.set("springs", list);
        try {
            plugin.getDataFolder().mkdirs();
            cfg.save(dataFile);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Could not save springs.yml", ex);
        }
    }

    private void loadData() {
        if (!dataFile.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(dataFile);
        List<String> list = cfg.getStringList("springs");
        for (String entry : list) {
            String[] parts = entry.split(",", 4);
            if (parts.length != 4) continue;
            World world = Bukkit.getWorld(parts[0]);
            if (world == null) continue;
            try {
                springs.add(new Location(world,
                        Integer.parseInt(parts[1]),
                        Integer.parseInt(parts[2]),
                        Integer.parseInt(parts[3])));
            } catch (NumberFormatException ignored) {}
        }
        plugin.getLogger().info("Loaded " + springs.size() + " spring(s).");
    }
}
