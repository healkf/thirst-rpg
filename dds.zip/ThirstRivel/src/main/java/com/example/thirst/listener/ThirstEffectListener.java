package com.example.thirst.listener;

import com.example.thirst.ThirstPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;

public class ThirstEffectListener implements Listener {

    private final ThirstPlugin plugin;

    public ThirstEffectListener(ThirstPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        int max = plugin.getConfig().getInt("max-thirst", 20);
        plugin.getThirstManager().setThirst(event.getPlayer(), max);
    }
}
